/**
 * EVO JavaScript Handler
 * Processes JavaScript code in .evo files with framework support
 */

class EvoJavaScriptHandler {
    constructor() {
        this.frameworks = {
            'react': {
                imports: ['import React from "react";', 'import ReactDOM from "react-dom";'],
                setup: 'ReactDOM.render(<App />, document.getElementById("root"));'
            },
            'vue': {
                imports: ['import { createApp } from "vue";'],
                setup: 'createApp(App).mount("#app");'
            },
            'tailwind': {
                imports: ['import "./tailwind.css";'],
                setup: '// Tailwind CSS loaded'
            },
            'node': {
                imports: ['import fs from "fs";', 'import path from "path";'],
                setup: '// Node.js environment'
            },
            'jquery': {
                imports: ['import $ from "jquery";'],
                setup: '$(document).ready(function() { /* jQuery ready */ });'
            },
            'bootstrap': {
                imports: ['import "bootstrap/dist/css/bootstrap.min.css";', 'import "bootstrap/dist/js/bootstrap.bundle.min.js";'],
                setup: '// Bootstrap loaded'
            }
        };
        
        this.processedCode = '';
        this.dependencies = new Set();
    }

    /**
     * Process JavaScript code in .evo files
     */
    processJavaScript(code, options = {}) {
        this.processedCode = code;
        
        // Extract framework requirements
        const frameworks = this.extractFrameworks(code);
        
        // Process framework-specific code
        frameworks.forEach(framework => {
            this.processFramework(framework, options);
        });
        
        // Process EVO-specific JavaScript syntax
        this.processEvoJavaScriptSyntax();
        
        // Generate imports and setup
        this.generateImportsAndSetup(frameworks);
        
        return {
            code: this.processedCode,
            dependencies: Array.from(this.dependencies),
            frameworks: frameworks
        };
    }

    /**
     * Extract framework requirements from code
     */
    extractFrameworks(code) {
        const frameworks = [];
        
        // Check for framework-specific syntax
        if (code.includes('evo:react') || code.includes('jsx') || code.includes('<Component')) {
            frameworks.push('react');
        }
        
        if (code.includes('evo:vue') || code.includes('Vue.createApp')) {
            frameworks.push('vue');
        }
        
        if (code.includes('evo:tailwind') || code.includes('class=') && code.includes('bg-')) {
            frameworks.push('tailwind');
        }
        
        if (code.includes('evo:node') || code.includes('require(') || code.includes('import fs')) {
            frameworks.push('node');
        }
        
        if (code.includes('evo:jquery') || code.includes('$(')) {
            frameworks.push('jquery');
        }
        
        if (code.includes('evo:bootstrap') || code.includes('btn-') || code.includes('container')) {
            frameworks.push('bootstrap');
        }
        
        return frameworks;
    }

    /**
     * Process framework-specific code
     */
    processFramework(framework, options) {
        switch (framework) {
            case 'react':
                this.processReactCode();
                break;
            case 'vue':
                this.processVueCode();
                break;
            case 'tailwind':
                this.processTailwindCode();
                break;
            case 'node':
                this.processNodeCode();
                break;
            case 'jquery':
                this.processJQueryCode();
                break;
            case 'bootstrap':
                this.processBootstrapCode();
                break;
        }
    }

    /**
     * Process React-specific code
     */
    processReactCode() {
        // Convert EVO React syntax to standard React
        this.processedCode = this.processedCode.replace(
            /evo:react\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/g,
            'function $1($2) { return ($3); }'
        );
        
        // Convert JSX-like syntax
        this.processedCode = this.processedCode.replace(
            /<(\w+)\s*([^>]*)>([^<]*)<\/\1>/g,
            'React.createElement("$1", {$2}, "$3")'
        );
        
        this.dependencies.add('react');
        this.dependencies.add('react-dom');
    }

    /**
     * Process Vue-specific code
     */
    processVueCode() {
        // Convert EVO Vue syntax to standard Vue
        this.processedCode = this.processedCode.replace(
            /evo:vue\s+(\w+)\s*\{([^}]+)\}/g,
            'const $1 = { $2 };'
        );
        
        this.dependencies.add('vue');
    }

    /**
     * Process Tailwind CSS
     */
    processTailwindCode() {
        // Process Tailwind classes
        this.processedCode = this.processedCode.replace(
            /class="([^"]*bg-[^"]*[^"]*)"/g,
            'className="$1"'
        );
        
        this.dependencies.add('tailwindcss');
        this.dependencies.add('autoprefixer');
    }

    /**
     * Process Node.js code
     */
    processNodeCode() {
        // Convert require to import
        this.processedCode = this.processedCode.replace(
            /require\(['"]([^'"]+)['"]\)/g,
            'import $1 from "$1";'
        );
        
        this.dependencies.add('node');
    }

    /**
     * Process jQuery code
     */
    processJQueryCode() {
        // Ensure jQuery is available
        this.processedCode = this.processedCode.replace(
            /\$\(/g,
            'jQuery('
        );
        
        this.dependencies.add('jquery');
    }

    /**
     * Process Bootstrap code
     */
    processBootstrapCode() {
        // Process Bootstrap classes
        this.processedCode = this.processedCode.replace(
            /class="([^"]*btn-[^"]*[^"]*)"/g,
            'className="$1"'
        );
        
        this.dependencies.add('bootstrap');
    }

    /**
     * Process EVO-specific JavaScript syntax
     */
    processEvoJavaScriptSyntax() {
        // EVO JavaScript variables
        this.processedCode = this.processedCode.replace(
            /evo:jsvar\s+(\w+)\s*=\s*(.+?);/g,
            'let $1 = $2;'
        );
        
        // EVO JavaScript functions
        this.processedCode = this.processedCode.replace(
            /evo:jsfunc\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/g,
            'function $1($2) { $3 }'
        );
        
        // EVO JavaScript classes
        this.processedCode = this.processedCode.replace(
            /evo:jsclass\s+(\w+)\s*\{([^}]+)\}/g,
            'class $1 { $2 }'
        );
        
        // EVO JavaScript async/await
        this.processedCode = this.processedCode.replace(
            /evo:async\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/g,
            'async function $1($2) { $3 }'
        );
        
        // EVO JavaScript promises
        this.processedCode = this.processedCode.replace(
            /evo:promise\s*\(([^)]*)\)\s*\{([^}]+)\}/g,
            'new Promise(($1) => { $2 })'
        );
        
        // EVO JavaScript modules
        this.processedCode = this.processedCode.replace(
            /evo:export\s+(\w+)/g,
            'export { $1 };'
        );
        
        this.processedCode = this.processedCode.replace(
            /evo:import\s+(\w+)\s+from\s+['"]([^'"]+)['"]/g,
            'import { $1 } from "$2";'
        );
    }

    /**
     * Generate imports and setup code
     */
    generateImportsAndSetup(frameworks) {
        let imports = '';
        let setup = '';
        
        frameworks.forEach(framework => {
            if (this.frameworks[framework]) {
                imports += this.frameworks[framework].imports.join('\n') + '\n';
                setup += this.frameworks[framework].setup + '\n';
            }
        });
        
        // Add EVO Bridge imports
        imports += 'import { EvoBridge } from "./evo-bridge.js";\n';
        
        // Combine everything
        this.processedCode = imports + '\n' + this.processedCode + '\n' + setup;
    }

    /**
     * Generate package.json dependencies
     */
    generatePackageJson() {
        const packageJson = {
            "name": "evo-project",
            "version": "1.0.0",
            "description": "EVO Programming Language Project",
            "main": "index.js",
            "scripts": {
                "dev": "evo-dev-server",
                "build": "evo-build",
                "start": "node dist/index.js",
                "test": "evo-test"
            },
            "dependencies": {},
            "devDependencies": {
                "evo-dev-server": "^1.0.0",
                "evo-build": "^1.0.0",
                "evo-test": "^1.0.0"
            },
            "keywords": ["evo", "programming-language", "php", "javascript"],
            "author": "EVO Developer",
            "license": "MIT"
        };
        
        // Add framework dependencies
        this.dependencies.forEach(dep => {
            if (dep === 'react') {
                packageJson.dependencies['react'] = '^18.0.0';
                packageJson.dependencies['react-dom'] = '^18.0.0';
            } else if (dep === 'vue') {
                packageJson.dependencies['vue'] = '^3.0.0';
            } else if (dep === 'tailwindcss') {
                packageJson.dependencies['tailwindcss'] = '^3.0.0';
                packageJson.dependencies['autoprefixer'] = '^10.0.0';
            } else if (dep === 'jquery') {
                packageJson.dependencies['jquery'] = '^3.6.0';
            } else if (dep === 'bootstrap') {
                packageJson.dependencies['bootstrap'] = '^5.0.0';
            }
        });
        
        return packageJson;
    }
}

// Export for use in Node.js environment
if (typeof module !== 'undefined' && module.exports) {
    module.exports = EvoJavaScriptHandler;
}

// Export for use in browser environment
if (typeof window !== 'undefined') {
    window.EvoJavaScriptHandler = EvoJavaScriptHandler;
}

