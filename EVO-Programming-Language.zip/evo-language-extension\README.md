# EVO Language Support Extension

This extension provides language support for the EVO programming language in Cursor/VSCode.

## Features

- ✅ **Syntax Highlighting** - Full syntax highlighting for EVO files
- ✅ **File Icons** - Custom EVO logo icons for .evo files
- ✅ **Code Snippets** - EVO syntax snippets and shortcuts
- ✅ **IntelliSense** - Auto-completion for EVO commands
- ✅ **Error Detection** - Syntax error detection and linting
- ✅ **Hover Help** - Helpful information on hover
- ✅ **Status Bar** - EVO status in the status bar

## Installation

### Method 1: Install from VSIX (Recommended)

1. Download the extension package:
   ```bash
   # In your project directory
   cd evo-language-extension
   npm install
   npm run compile
   npm run package
   ```

2. Install the extension:
   - Open Cursor/VSCode
   - Go to Extensions (Ctrl+Shift+X)
   - Click the "..." menu
   - Select "Install from VSIX..."
   - Choose the generated `.vsix` file

### Method 2: Install from Source

1. Clone or download this extension
2. Open in Cursor/VSCode
3. Press F5 to run the extension in a new window
4. Or use the Command Palette (Ctrl+Shift+P) and run "Extensions: Install Extension"

### Method 3: Manual Installation

1. Copy the extension folder to your extensions directory:
   - **Windows:** `%USERPROFILE%\.vscode\extensions\`
   - **macOS:** `~/.vscode/extensions/`
   - **Linux:** `~/.vscode/extensions/`

2. Restart Cursor/VSCode

## Usage

Once installed, the extension will:

1. **Automatically recognize .evo files** with the EVO logo icon
2. **Provide syntax highlighting** for EVO, PHP, and JavaScript code
3. **Show code snippets** when you type `evo:`
4. **Display hover help** for EVO commands
5. **Show EVO status** in the status bar

## EVO Syntax Support

The extension supports all EVO syntax:

- `evo:var` - Variables
- `evo:func` - Functions
- `evo:class` - Classes
- `evo:if` - Conditionals
- `evo:for` - Loops
- `evo:out` - Output
- `evo:share` - Data sharing
- `evo:react` - React components
- `evo:tailwind` - Tailwind CSS
- `evo:node` - Node.js modules

## Commands

- `EVO: Run File` - Run the current .evo file
- `EVO: Start Dev Server` - Start the EVO development server

## File Icons

The extension provides custom EVO logo icons:
- Light theme: Blue EVO logo
- Dark theme: Dark blue EVO logo
- File explorer: EVO logo before .evo files

## Configuration

The extension can be configured in your settings:

```json
{
  "evo.enableSyntaxHighlighting": true,
  "evo.enableSnippets": true,
  "evo.enableIntelliSense": true,
  "evo.enableErrorDetection": true
}
```

## Troubleshooting

### Extension not working?
1. Make sure the extension is enabled
2. Restart Cursor/VSCode
3. Check the Output panel for errors

### Icons not showing?
1. Make sure you have the EVO icon theme selected
2. Go to File > Preferences > File Icon Theme
3. Select "EVO Icons"

### Syntax highlighting not working?
1. Make sure .evo files are recognized as EVO language
2. Check the bottom-right corner of the editor
3. Click on the language and select "EVO"

## Development

To contribute to this extension:

1. Clone the repository
2. Run `npm install`
3. Run `npm run compile` to build
4. Press F5 to test in a new window

## License

MIT License - see LICENSE file for details.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Create an issue in the repository
3. Join the EVO community

---

**EVO Language Support** - Making EVO programming language development easier! 🚀

