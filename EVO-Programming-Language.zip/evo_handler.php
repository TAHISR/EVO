<?php
/**
 * .EVO Programming Language Handler
 * Processes .evo files as a complete programming language
 */

// Set content type to HTML
header('Content-Type: text/html; charset=utf-8');

// Get the requested .evo file path
$request_uri = $_SERVER['REQUEST_URI'];
$script_name = $_SERVER['SCRIPT_NAME'];

// Extract the .evo file path from the request
$evo_file = '';
if (strpos($request_uri, '.evo') !== false) {
    // Remove query string if present
    $path = parse_url($request_uri, PHP_URL_PATH);
    
    // Get the .evo file path relative to document root
    $evo_file = $_SERVER['DOCUMENT_ROOT'] . $path;
    
    // Check if file exists
    if (file_exists($evo_file)) {
        // Check if it's actually a .evo file
        if (pathinfo($evo_file, PATHINFO_EXTENSION) === 'evo') {
            // Start output buffering to capture any output
            ob_start();
            
            try {
                // Read the .evo file content
                $content = file_get_contents($evo_file);
                
                // Process the content as .evo programming language
                $processed_content = processEvoLanguage($content);
                
                // Execute the processed content
                eval('?>' . $processed_content);
                
                // Get the output
                $output = ob_get_contents();
                ob_end_clean();
                
                // Display the output
                echo $output;
                
            } catch (Exception $e) {
                ob_end_clean();
                echo "<h1>EVO Language Error</h1>";
                echo "<p><strong>File:</strong> " . htmlspecialchars($evo_file) . "</p>";
                echo "<p><strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "</p>";
                echo "<p><strong>Line:</strong> " . $e->getLine() . "</p>";
            }
        } else {
            http_response_code(404);
            echo "<h1>File Not Found</h1><p>The requested file is not a .evo file.</p>";
        }
    } else {
        http_response_code(404);
        echo "<h1>File Not Found</h1><p>The requested .evo file does not exist.</p>";
    }
} else {
    http_response_code(400);
    echo "<h1>Bad Request</h1><p>This handler only processes .evo files.</p>";
}

/**
 * Process .evo file content as a programming language
 * 
 * @param string $content The raw .evo file content
 * @return string Processed content ready for PHP execution
 */
function processEvoLanguage($content) {
    // Initialize EVO language features
    $evo = new EvoLanguage();
    
    // Process the content through the EVO language parser
    return $evo->parse($content);
}

/**
 * EVO Programming Language Class
 * Creates seamless bridge between PHP and JavaScript
 */
class EvoLanguage {
    private $variables = [];
    private $functions = [];
    private $classes = [];
    private $phpToJsBridge = [];
    private $jsToPhpBridge = [];
    
    public function parse($content) {
        // Step 1: Process EVO-specific syntax
        $content = $this->processEvoSyntax($content);
        
        // Step 2: Create PHP-JavaScript bridge
        $content = $this->createPhpJsBridge($content);
        
        // Step 3: Process mixed content (PHP + JavaScript)
        $content = $this->processMixedContent($content);
        
        return $content;
    }
    
    private function processEvoSyntax($content) {
        // EVO Language Features:
        
        // 1. EVO Variables (evo:var name = value)
        $content = preg_replace_callback('/evo:var\s+(\w+)\s*=\s*(.+?);/s', function($matches) {
            $varName = $matches[1];
            $varValue = $matches[2];
            return "<?php \$$varName = $varValue; ?>";
        }, $content);
        
        // 2. EVO Functions (evo:func name() { ... })
        $content = preg_replace_callback('/evo:func\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/s', function($matches) {
            $funcName = $matches[1];
            $params = $matches[2];
            $body = $matches[3];
            return "<?php function $funcName($params) { $body } ?>";
        }, $content);
        
        // 3. EVO Classes (evo:class name { ... })
        $content = preg_replace_callback('/evo:class\s+(\w+)\s*\{([^}]+)\}/s', function($matches) {
            $className = $matches[1];
            $classBody = $matches[2];
            return "<?php class $className { $classBody } ?>";
        }, $content);
        
        // 4. EVO Output (evo:out expression)
        $content = preg_replace_callback('/evo:out\s+(.+?);/s', function($matches) {
            $expression = $matches[1];
            return "<?php echo $expression; ?>";
        }, $content);
        
        // 5. EVO Include (evo:include file)
        $content = preg_replace_callback('/evo:include\s+["\']([^"\']+)["\'];/s', function($matches) {
            $file = $matches[1];
            return "<?php include '$file'; ?>";
        }, $content);
        
        // 6. EVO If statements (evo:if condition { ... })
        $content = preg_replace_callback('/evo:if\s+\(([^)]+)\)\s*\{([^}]+)\}/s', function($matches) {
            $condition = $matches[1];
            $body = $matches[2];
            return "<?php if ($condition) { $body } ?>";
        }, $content);
        
        // 7. EVO For loops (evo:for var in range { ... })
        $content = preg_replace_callback('/evo:for\s+(\w+)\s+in\s+([^}]+)\s*\{([^}]+)\}/s', function($matches) {
            $var = $matches[1];
            $range = $matches[2];
            $body = $matches[3];
            return "<?php foreach ($range as \$$var) { $body } ?>";
        }, $content);
        
        // 8. EVO While loops (evo:while condition { ... })
        $content = preg_replace_callback('/evo:while\s+\(([^)]+)\)\s*\{([^}]+)\}/s', function($matches) {
            $condition = $matches[1];
            $body = $matches[2];
            return "<?php while ($condition) { $body } ?>";
        }, $content);
        
        // 9. EVO Comments (evo:// comment)
        $content = preg_replace('/evo:\/\/.*$/m', '', $content);
        
        // 10. EVO Multi-line comments (evo:/* comment */)
        $content = preg_replace('/evo:\/\*.*?\*\//s', '', $content);
        
        return $content;
    }
    
    /**
     * Create seamless bridge between PHP and JavaScript
     */
    private function createPhpJsBridge($content) {
        // Add EVO logo and branding
        $content = $this->addEvoBranding($content);
        
        // Add EVO Bridge JavaScript library
        $bridgeScript = '
        <script>
        // EVO PHP-JavaScript Bridge
        window.EvoBridge = {
            // PHP to JavaScript communication
            phpData: {},
            
            // JavaScript to PHP communication
            phpRequests: [],
            
            // Initialize bridge
            init: function() {
                console.log("EVO Bridge initialized");
                this.setupEventListeners();
            },
            
            // Setup event listeners for PHP-JavaScript communication
            setupEventListeners: function() {
                // Listen for PHP data updates
                document.addEventListener("evo:phpData", function(e) {
                    EvoBridge.phpData = e.detail;
                    console.log("PHP data received:", EvoBridge.phpData);
                });
                
                // Listen for JavaScript to PHP requests
                document.addEventListener("evo:jsToPhp", function(e) {
                    EvoBridge.handleJsToPhpRequest(e.detail);
                });
            },
            
            // Handle JavaScript to PHP requests
            handleJsToPhpRequest: function(request) {
                fetch("/evo-bridge.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify(request)
                })
                .then(response => response.json())
                .then(data => {
                    // Trigger event with PHP response
                    const event = new CustomEvent("evo:phpResponse", {
                        detail: { request: request, response: data }
                    });
                    document.dispatchEvent(event);
                })
                .catch(error => {
                    console.error("PHP request failed:", error);
                });
            },
            
            // Send data from PHP to JavaScript
            sendToJs: function(data) {
                const event = new CustomEvent("evo:phpData", { detail: data });
                document.dispatchEvent(event);
            },
            
            // Send request from JavaScript to PHP
            sendToPhp: function(action, data) {
                const request = { action: action, data: data };
                const event = new CustomEvent("evo:jsToPhp", { detail: request });
                document.dispatchEvent(event);
            },
            
            // Get PHP data in JavaScript
            getPhpData: function(key) {
                return this.phpData[key];
            },
            
            // Set PHP data from JavaScript
            setPhpData: function(key, value) {
                this.phpData[key] = value;
                this.sendToPhp("updateData", { key: key, value: value });
            }
        };
        
        // Initialize bridge when DOM is ready
        document.addEventListener("DOMContentLoaded", function() {
            EvoBridge.init();
        });
        </script>';
        
        // Insert bridge script before closing head tag
        $content = str_replace('</head>', $bridgeScript . '</head>', $content);
        
        // Process PHP-JavaScript bridge syntax
        $content = $this->processBridgeSyntax($content);
        
        return $content;
    }
    
    /**
     * Add EVO branding and logo to content
     */
    private function addEvoBranding($content) {
        // Add EVO logo to HTML head if not already present
        if (strpos($content, '<head>') !== false && strpos($content, 'evologo.png') === false) {
            $logoScript = '
            <style>
                .evo-logo {
                    position: fixed;
                    top: 10px;
                    right: 10px;
                    width: 50px;
                    height: 50px;
                    z-index: 9999;
                    opacity: 0.8;
                    transition: opacity 0.3s ease;
                }
                .evo-logo:hover {
                    opacity: 1;
                }
                .evo-branding {
                    position: fixed;
                    bottom: 10px;
                    right: 10px;
                    background: rgba(0, 0, 0, 0.8);
                    color: white;
                    padding: 5px 10px;
                    border-radius: 5px;
                    font-size: 12px;
                    z-index: 9999;
                    font-family: monospace;
                }
            </style>
            <img src="evologo.png" alt="EVO Logo" class="evo-logo" title="EVO Programming Language">
            <div class="evo-branding">Powered by EVO</div>';
            
            $content = str_replace('</head>', $logoScript . '</head>', $content);
        }
        
        return $content;
    }
    
    /**
     * Process bridge syntax for seamless PHP-JavaScript communication
     */
    private function processBridgeSyntax($content) {
        // 1. Built-in React support
        $content = $this->processBuiltInReact($content);
        
        // 2. Built-in Tailwind CSS support
        $content = $this->processBuiltInTailwind($content);
        
        // 3. Built-in Node.js support
        $content = $this->processBuiltInNodeJS($content);
        
        // 4. PHP to JavaScript data sharing (evo:share variable)
        $content = preg_replace_callback('/evo:share\s+(\w+);/s', function($matches) {
            $varName = $matches[1];
            return "<?php echo '<script>EvoBridge.sendToJs({\"$varName\": \$$varName});</script>'; ?>";
        }, $content);
        
        // 2. JavaScript to PHP function calls (evo:call function)
        $content = preg_replace_callback('/evo:call\s+(\w+)\s*\(([^)]*)\);/s', function($matches) {
            $funcName = $matches[1];
            $params = $matches[2];
            return "<?php echo '<script>EvoBridge.sendToPhp(\"$funcName\", {' . $params . '});</script>'; ?>";
        }, $content);
        
        // 3. JavaScript functions that can be called from PHP (evo:jsfunc name)
        $content = preg_replace_callback('/evo:jsfunc\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/s', function($matches) {
            $funcName = $matches[1];
            $params = $matches[2];
            $body = $matches[3];
            return "<script>function $funcName($params) { $body }</script>";
        }, $content);
        
        // 4. PHP functions that can be called from JavaScript (evo:phpfunc name)
        $content = preg_replace_callback('/evo:phpfunc\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/s', function($matches) {
            $funcName = $matches[1];
            $params = $matches[2];
            $body = $matches[3];
            return "<?php function $funcName($params) { $body } ?>";
        }, $content);
        
        // 5. Auto-bridge: PHP variables automatically available in JavaScript
        $content = preg_replace_callback('/evo:auto\s+(\w+);/s', function($matches) {
            $varName = $matches[1];
            return "<?php echo '<script>EvoBridge.phpData.$varName = ' . json_encode(\$$varName) . ';</script>'; ?>";
        }, $content);
        
        return $content;
    }
    
    /**
     * Process built-in React support
     */
    private function processBuiltInReact($content) {
        // Add React CDN if not already present
        if (strpos($content, '<head>') !== false && strpos($content, 'react') === false) {
            $reactScript = '
            <!-- EVO Built-in React Support -->
            <script crossorigin src="https://unpkg.com/react@18/umd/react.development.js"></script>
            <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
            <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>';
            
            $content = str_replace('</head>', $reactScript . '</head>', $content);
        }
        
        // Process React components
        $content = preg_replace_callback('/evo:react\s+(\w+)\s*\(([^)]*)\)\s*\{([^}]+)\}/s', function($matches) {
            $componentName = $matches[1];
            $props = $matches[2];
            $body = $matches[3];
            
            return "
            <script type=\"text/babel\">
                function $componentName($props) {
                    return ($body);
                }
                
                // Auto-render if component is used in HTML
                if (document.querySelector('[data-react-component=\"$componentName\"]')) {
                    const container = document.querySelector('[data-react-component=\"$componentName\"]');
                    const root = ReactDOM.createRoot(container);
                    root.render(React.createElement($componentName, {}));
                }
            </script>";
        }, $content);
        
        return $content;
    }
    
    /**
     * Process built-in Tailwind CSS support
     */
    private function processBuiltInTailwind($content) {
        // Add Tailwind CSS CDN if not already present
        if (strpos($content, '<head>') !== false && strpos($content, 'tailwindcss') === false) {
            $tailwindScript = '
            <!-- EVO Built-in Tailwind CSS Support -->
            <script src="https://cdn.tailwindcss.com"></script>
            <script>
                tailwind.config = {
                    theme: {
                        extend: {
                            colors: {
                                evo: {
                                    primary: "#3498db",
                                    secondary: "#2c3e50",
                                    accent: "#e74c3c"
                                }
                            }
                        }
                    }
                }
            </script>';
            
            $content = str_replace('</head>', $tailwindScript . '</head>', $content);
        }
        
        // Process Tailwind classes
        $content = preg_replace_callback('/evo:tailwind\s+["\']([^"\']+)["\']/s', function($matches) {
            $classes = $matches[1];
            return "class=\"$classes\"";
        }, $content);
        
        // Process Tailwind utility classes
        $content = preg_replace_callback('/evo:tw\s+(\w+)/s', function($matches) {
            $utility = $matches[1];
            $classMap = [
                'container' => 'container mx-auto px-4',
                'card' => 'bg-white rounded-lg shadow-md p-6',
                'button' => 'bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded',
                'input' => 'border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500',
                'text' => 'text-gray-800',
                'heading' => 'text-2xl font-bold text-gray-900',
                'flex' => 'flex items-center justify-center',
                'grid' => 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'
            ];
            
            return isset($classMap[$utility]) ? $classMap[$utility] : $utility;
        }, $content);
        
        return $content;
    }
    
    /**
     * Process built-in Node.js support
     */
    private function processBuiltInNodeJS($content) {
        // Add Node.js polyfills for browser environment
        if (strpos($content, '<head>') !== false && strpos($content, 'node-polyfill') === false) {
            $nodeScript = '
            <!-- EVO Built-in Node.js Support -->
            <script src="https://unpkg.com/node-polyfill-webpack-plugin@2.0.1/dist/index.js"></script>
            <script>
                // Node.js polyfills for browser
                if (typeof global === "undefined") {
                    window.global = window;
                }
                
                // Mock Node.js modules
                window.require = function(module) {
                    const modules = {
                        "fs": {
                            readFileSync: function(path) {
                                return "Mock file content for: " + path;
                            },
                            writeFileSync: function(path, data) {
                                console.log("Mock write to:", path, data);
                            }
                        },
                        "path": {
                            join: function(...args) {
                                return args.join("/");
                            },
                            resolve: function(...args) {
                                return args.join("/");
                            }
                        },
                        "http": {
                            createServer: function(callback) {
                                console.log("Mock HTTP server created");
                                return {
                                    listen: function(port) {
                                        console.log("Mock server listening on port", port);
                                    }
                                };
                            }
                        }
                    };
                    return modules[module] || {};
                };
                
                // Make Node.js modules available globally
                window.fs = window.require("fs");
                window.path = window.require("path");
                window.http = window.require("http");
            </script>';
            
            $content = str_replace('</head>', $nodeScript . '</head>', $content);
        }
        
        // Process Node.js module imports
        $content = preg_replace_callback('/evo:node\s+(\w+)/s', function($matches) {
            $module = $matches[1];
            return "<script>const $module = require('$module');</script>";
        }, $content);
        
        return $content;
    }
    
    private function processMixedContent($content) {
        // Split content by PHP tags
        $parts = preg_split('/(<\?php|<\?=|\?>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE);
        
        $processed = '';
        $in_php = false;
        
        for ($i = 0; $i < count($parts); $i++) {
            $part = $parts[$i];
            
            if ($part === '<?php' || $part === '<?=') {
                $in_php = true;
                $processed .= $part;
            } elseif ($part === '?>') {
                $in_php = false;
                $processed .= $part;
            } else {
                if ($in_php) {
                    // This is PHP code, keep as is
                    $processed .= $part;
                } else {
                    // This is non-PHP content (HTML/JavaScript), wrap in echo
                    if (trim($part) !== '') {
                        // Escape the content for PHP echo
                        $escaped = addslashes($part);
                        $processed .= "echo '" . $escaped . "';";
                    }
                }
            }
        }
        
        return $processed;
    }
}
?>
