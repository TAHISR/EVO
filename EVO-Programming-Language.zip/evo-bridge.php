<?php
/**
 * EVO Bridge Handler
 * Handles JavaScript to PHP communication
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (!$data) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON data']);
    exit();
}

// Process the request
$response = processEvoRequest($data);

// Send response
echo json_encode($response);

/**
 * Process EVO bridge requests
 */
function processEvoRequest($data) {
    $action = $data['action'] ?? '';
    $requestData = $data['data'] ?? [];
    
    switch ($action) {
        case 'processData':
            return processData($requestData);
            
        case 'updateData':
            return updateData($requestData);
            
        case 'calculate':
            return calculate($requestData);
            
        case 'validateForm':
            return validateForm($requestData);
            
        case 'getServerInfo':
            return getServerInfo();
            
        case 'databaseQuery':
            return databaseQuery($requestData);
            
        default:
            return ['error' => 'Unknown action: ' . $action];
    }
}

/**
 * Process data calculation
 */
function processData($data) {
    if (isset($data['numbers']) && is_array($data['numbers'])) {
        $numbers = $data['numbers'];
        $sum = array_sum($numbers);
        $average = $sum / count($numbers);
        $max = max($numbers);
        $min = min($numbers);
        
        return [
            'success' => true,
            'result' => [
                'sum' => $sum,
                'average' => round($average, 2),
                'max' => $max,
                'min' => $min,
                'count' => count($numbers)
            ]
        ];
    }
    
    return ['error' => 'Invalid data format'];
}

/**
 * Update data
 */
function updateData($data) {
    $key = $data['key'] ?? '';
    $value = $data['value'] ?? '';
    
    // In a real application, you would save this to a database or session
    // For demo purposes, we'll just return success
    
    return [
        'success' => true,
        'message' => "Data updated: $key = " . json_encode($value)
    ];
}

/**
 * Calculate mathematical operations
 */
function calculate($data) {
    $operation = $data['operation'] ?? '';
    $numbers = $data['numbers'] ?? [];
    
    if (empty($numbers)) {
        return ['error' => 'No numbers provided'];
    }
    
    switch ($operation) {
        case 'sum':
            return ['result' => array_sum($numbers)];
            
        case 'product':
            return ['result' => array_product($numbers)];
            
        case 'average':
            return ['result' => array_sum($numbers) / count($numbers)];
            
        case 'max':
            return ['result' => max($numbers)];
            
        case 'min':
            return ['result' => min($numbers)];
            
        default:
            return ['error' => 'Unknown operation: ' . $operation];
    }
}

/**
 * Validate form data
 */
function validateForm($data) {
    $errors = [];
    
    // Validate name
    if (empty($data['name'])) {
        $errors['name'] = 'Name is required';
    } elseif (strlen($data['name']) < 2) {
        $errors['name'] = 'Name must be at least 2 characters';
    }
    
    // Validate email
    if (empty($data['email'])) {
        $errors['email'] = 'Email is required';
    } elseif (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Invalid email format';
    }
    
    // Validate age
    if (empty($data['age'])) {
        $errors['age'] = 'Age is required';
    } elseif (!is_numeric($data['age']) || $data['age'] < 1 || $data['age'] > 120) {
        $errors['age'] = 'Age must be between 1 and 120';
    }
    
    if (empty($errors)) {
        return [
            'success' => true,
            'message' => 'Form is valid',
            'data' => $data
        ];
    } else {
        return [
            'success' => false,
            'errors' => $errors
        ];
    }
}

/**
 * Get server information
 */
function getServerInfo() {
    return [
        'success' => true,
        'server' => [
            'php_version' => PHP_VERSION,
            'server_software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
            'server_time' => date('Y-m-d H:i:s'),
            'timezone' => date_default_timezone_get(),
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time')
        ]
    ];
}

/**
 * Database query (demo)
 */
function databaseQuery($data) {
    $query = $data['query'] ?? '';
    
    // In a real application, you would execute actual database queries
    // For demo purposes, we'll simulate some results
    
    switch ($query) {
        case 'getUsers':
            return [
                'success' => true,
                'data' => [
                    ['id' => 1, 'name' => 'John Doe', 'email' => 'john@example.com'],
                    ['id' => 2, 'name' => 'Jane Smith', 'email' => 'jane@example.com'],
                    ['id' => 3, 'name' => 'Bob Johnson', 'email' => 'bob@example.com']
                ]
            ];
            
        case 'getProducts':
            return [
                'success' => true,
                'data' => [
                    ['id' => 1, 'name' => 'Laptop', 'price' => 999.99],
                    ['id' => 2, 'name' => 'Mouse', 'price' => 29.99],
                    ['id' => 3, 'name' => 'Keyboard', 'price' => 79.99]
                ]
            ];
            
        default:
            return ['error' => 'Unknown query: ' . $query];
    }
}
?>

