const vscode = require('vscode');

function activate(context) {
    console.log('EVO Language Support extension is now active!');

    // Register EVO language
    const evoLanguage = vscode.languages.registerDocumentFormattingEditProvider('evo', {
        provideDocumentFormattingEdits(document, options, token) {
            return formatEvoDocument(document, options);
        }
    });

    // Register EVO commands
    const runEvoFile = vscode.commands.registerCommand('evo.runFile', () => {
        const activeEditor = vscode.window.activeTextEditor;
        if (activeEditor && activeEditor.document.languageId === 'evo') {
            runEvoFileCommand(activeEditor.document);
        } else {
            vscode.window.showWarningMessage('Please open a .evo file first');
        }
    });

    const startDevServer = vscode.commands.registerCommand('evo.startDevServer', () => {
        startEvoDevServer();
    });

    // Register hover provider for EVO syntax
    const hoverProvider = vscode.languages.registerHoverProvider('evo', {
        provideHover(document, position, token) {
            return provideEvoHover(document, position);
        }
    });

    // Register completion provider for EVO syntax
    const completionProvider = vscode.languages.registerCompletionItemProvider('evo', {
        provideCompletionItems(document, position, token, context) {
            return provideEvoCompletions(document, position);
        }
    }, 'evo:');

    // Register diagnostic provider for EVO syntax
    const diagnosticProvider = vscode.languages.registerDiagnosticProvider('evo', {
        provideDiagnostics(document, token) {
            return provideEvoDiagnostics(document);
        }
    });

    // Add EVO logo to status bar
    const statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Right, 100);
    statusBarItem.text = "$(symbol-method) EVO";
    statusBarItem.tooltip = "EVO Programming Language";
    statusBarItem.command = 'evo.startDevServer';
    statusBarItem.show();

    // Register all providers
    context.subscriptions.push(
        evoLanguage,
        runEvoFile,
        startDevServer,
        hoverProvider,
        completionProvider,
        diagnosticProvider,
        statusBarItem
    );
}

function deactivate() {
    console.log('EVO Language Support extension is now deactivated');
}

function formatEvoDocument(document, options) {
    const edits = [];
    const text = document.getText();
    
    // Basic formatting for EVO syntax
    const lines = text.split('\n');
    let formattedLines = [];
    
    for (let i = 0; i < lines.length; i++) {
        let line = lines[i];
        
        // Format EVO syntax
        if (line.includes('evo:')) {
            // Add proper indentation
            const indent = line.match(/^\s*/)[0];
            line = line.replace(/evo:(\w+)/g, 'evo:$1');
        }
        
        formattedLines.push(line);
    }
    
    const formattedText = formattedLines.join('\n');
    if (formattedText !== text) {
        const fullRange = new vscode.Range(
            document.positionAt(0),
            document.positionAt(text.length)
        );
        edits.push(vscode.TextEdit.replace(fullRange, formattedText));
    }
    
    return edits;
}

function runEvoFileCommand(document) {
    const fileName = document.fileName;
    const terminal = vscode.window.createTerminal('EVO Runner');
    
    terminal.sendText(`php -S localhost:8000`);
    terminal.show();
    
    vscode.window.showInformationMessage(`EVO file running at http://localhost:8000/${document.fileName.split('/').pop()}`);
}

function startEvoDevServer() {
    const terminal = vscode.window.createTerminal('EVO Dev Server');
    
    terminal.sendText('npm run dev');
    terminal.show();
    
    vscode.window.showInformationMessage('EVO Development Server started!');
}

function provideEvoHover(document, position) {
    const line = document.lineAt(position.line).text;
    const word = document.getText(document.getWordRangeAtPosition(position));
    
    // Provide hover information for EVO syntax
    if (word.startsWith('evo:')) {
        const syntax = word.substring(4);
        const hoverText = getEvoSyntaxHelp(syntax);
        
        if (hoverText) {
            return new vscode.Hover(hoverText);
        }
    }
    
    return null;
}

function provideEvoCompletions(document, position) {
    const completions = [];
    
    // EVO syntax completions
    const evoSyntaxes = [
        'var', 'func', 'class', 'if', 'for', 'while', 'out', 'include',
        'share', 'call', 'jsfunc', 'phpfunc', 'auto', 'jsvar', 'jsclass',
        'async', 'promise', 'export', 'import', 'react', 'vue', 'tailwind',
        'node', 'jquery', 'bootstrap'
    ];
    
    evoSyntaxes.forEach(syntax => {
        const completion = new vscode.CompletionItem(`evo:${syntax}`, vscode.CompletionItemKind.Keyword);
        completion.detail = `EVO ${syntax}`;
        completion.documentation = getEvoSyntaxHelp(syntax);
        completions.push(completion);
    });
    
    return completions;
}

function provideEvoDiagnostics(document) {
    const diagnostics = [];
    const text = document.getText();
    const lines = text.split('\n');
    
    for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // Check for common EVO syntax errors
        if (line.includes('evo:') && !line.match(/evo:\w+\s+/)) {
            const diagnostic = new vscode.Diagnostic(
                new vscode.Range(i, 0, i, line.length),
                'Invalid EVO syntax. Expected: evo:keyword',
                vscode.DiagnosticSeverity.Error
            );
            diagnostics.push(diagnostic);
        }
    }
    
    return diagnostics;
}

function getEvoSyntaxHelp(syntax) {
    const helpTexts = {
        'var': 'Creates an EVO variable: evo:var name = value;',
        'func': 'Creates an EVO function: evo:func name(params) { body }',
        'class': 'Creates an EVO class: evo:class Name { body }',
        'if': 'Creates an EVO if statement: evo:if (condition) { body }',
        'for': 'Creates an EVO for loop: evo:for item in array { body }',
        'while': 'Creates an EVO while loop: evo:while (condition) { body }',
        'out': 'Outputs with EVO: evo:out expression;',
        'include': 'Includes a file: evo:include "file.evo";',
        'share': 'Shares PHP variable with JavaScript: evo:share variableName;',
        'call': 'Calls JavaScript function from PHP: evo:call functionName(params);',
        'jsfunc': 'Creates JavaScript function: evo:jsfunc name(params) { body }',
        'phpfunc': 'Creates PHP function: evo:phpfunc name(params) { body }',
        'auto': 'Auto-bridges PHP variable to JavaScript: evo:auto variableName;',
        'react': 'Creates React component: evo:react ComponentName(props) { return JSX; }',
        'vue': 'Creates Vue component: evo:vue ComponentName { template: "...", data() { ... } }',
        'tailwind': 'Uses Tailwind CSS: evo:tailwind "class-name"',
        'node': 'Uses Node.js module: evo:node moduleName',
        'jquery': 'Uses jQuery: evo:jquery "selector"',
        'bootstrap': 'Uses Bootstrap: evo:bootstrap "component-class"'
    };
    
    return helpTexts[syntax] || `EVO ${syntax} syntax`;
}

module.exports = {
    activate,
    deactivate
};

