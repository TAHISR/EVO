const vsce = require('vsce');
const path = require('path');

async function package() {
    try {
        console.log('📦 Packaging EVO Language Support Extension...');
        
        // Package the extension
        await vsce.createVSIX({
            packagePath: path.join(__dirname, '..', 'evo-language-support.vsix'),
            cwd: path.join(__dirname, '..')
        });
        
        console.log('✅ Extension packaged successfully!');
        console.log('📁 Package location: evo-language-support.vsix');
        console.log('');
        console.log('📋 Installation Instructions:');
        console.log('1. Open Cursor/VSCode');
        console.log('2. Go to Extensions (Ctrl+Shift+X)');
        console.log('3. Click the "..." menu');
        console.log('4. Select "Install from VSIX..."');
        console.log('5. Choose the evo-language-support.vsix file');
        console.log('6. Restart Cursor/VSCode');
        console.log('');
        console.log('🎉 Your EVO logo will now appear before .evo files!');
        
    } catch (error) {
        console.error('❌ Error packaging extension:', error);
        process.exit(1);
    }
}

package();

