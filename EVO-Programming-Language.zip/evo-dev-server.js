#!/usr/bin/env node

/**
 * EVO Development Server
 * Handles development workflow for .evo files
 */

const fs = require('fs');
const path = require('path');
const http = require('http');
const { exec } = require('child_process');
const chokidar = require('chokidar');

class EvoDevServer {
    constructor(options = {}) {
        this.port = options.port || 3000;
        this.phpPort = options.phpPort || 8000;
        this.watch = options.watch || false;
        this.frameworks = options.frameworks || [];
        this.isRunning = false;
        this.watchers = [];
    }

    /**
     * Start the development server
     */
    async start() {
        console.log('🚀 Starting EVO Development Server...');
        
        // Check for .evo files
        const evoFiles = this.findEvoFiles();
        if (evoFiles.length === 0) {
            console.log('⚠️  No .evo files found in current directory');
        } else {
            console.log(`📁 Found ${evoFiles.length} .evo files`);
        }
        
        // Start PHP server
        await this.startPhpServer();
        
        // Start JavaScript handler
        await this.startJavaScriptHandler();
        
        // Start main development server
        await this.startMainServer();
        
        // Setup file watching
        if (this.watch) {
            this.setupFileWatching();
        }
        
        this.isRunning = true;
        console.log(`✅ EVO Development Server running on http://localhost:${this.port}`);
        console.log(`📱 PHP Server running on http://localhost:${this.phpPort}`);
        console.log('🎯 Ready for development!');
    }

    /**
     * Find all .evo files in the project
     */
    findEvoFiles() {
        const evoFiles = [];
        
        function scanDirectory(dir) {
            const files = fs.readdirSync(dir);
            
            files.forEach(file => {
                const filePath = path.join(dir, file);
                const stat = fs.statSync(filePath);
                
                if (stat.isDirectory() && !file.startsWith('.') && file !== 'node_modules') {
                    scanDirectory(filePath);
                } else if (file.endsWith('.evo')) {
                    evoFiles.push(filePath);
                }
            });
        }
        
        scanDirectory(process.cwd());
        return evoFiles;
    }

    /**
     * Start PHP server
     */
    async startPhpServer() {
        return new Promise((resolve, reject) => {
            const phpProcess = exec(`php -S localhost:${this.phpPort}`, (error, stdout, stderr) => {
                if (error) {
                    console.error('❌ PHP Server error:', error);
                    reject(error);
                }
            });
            
            // Give PHP server time to start
            setTimeout(() => {
                console.log(`🐘 PHP Server started on port ${this.phpPort}`);
                resolve();
            }, 1000);
        });
    }

    /**
     * Start JavaScript handler
     */
    async startJavaScriptHandler() {
        const EvoJavaScriptHandler = require('./evo-js-handler.js');
        this.jsHandler = new EvoJavaScriptHandler();
        console.log('📜 JavaScript Handler initialized');
    }

    /**
     * Start main development server
     */
    async startMainServer() {
        const server = http.createServer((req, res) => {
            this.handleRequest(req, res);
        });
        
        server.listen(this.port, () => {
            console.log(`🌐 Main server listening on port ${this.port}`);
        });
    }

    /**
     * Handle HTTP requests
     */
    handleRequest(req, res) {
        const url = new URL(req.url, `http://localhost:${this.port}`);
        const pathname = url.pathname;
        
        // Set CORS headers
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
        
        if (req.method === 'OPTIONS') {
            res.writeHead(200);
            res.end();
            return;
        }
        
        // Handle .evo files
        if (pathname.endsWith('.evo')) {
            this.handleEvoFile(pathname, res);
        }
        // Handle JavaScript files
        else if (pathname.endsWith('.js')) {
            this.handleJavaScriptFile(pathname, res);
        }
        // Handle CSS files
        else if (pathname.endsWith('.css')) {
            this.handleCssFile(pathname, res);
        }
        // Handle API requests
        else if (pathname.startsWith('/api/')) {
            this.handleApiRequest(pathname, req, res);
        }
        // Serve static files
        else {
            this.serveStaticFile(pathname, res);
        }
    }

    /**
     * Handle .evo file requests
     */
    handleEvoFile(pathname, res) {
        const filePath = path.join(process.cwd(), pathname);
        
        if (!fs.existsSync(filePath)) {
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end('<h1>404 - .evo file not found</h1>');
            return;
        }
        
        // Read and process .evo file
        const content = fs.readFileSync(filePath, 'utf8');
        const processedContent = this.processEvoFile(content);
        
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(processedContent);
    }

    /**
     * Process .evo file content
     */
    processEvoFile(content) {
        // Process PHP code
        const phpProcessed = this.processPhpCode(content);
        
        // Process JavaScript code
        const jsProcessed = this.processJavaScriptCode(phpProcessed);
        
        return jsProcessed;
    }

    /**
     * Process PHP code in .evo files
     */
    processPhpCode(content) {
        // This would integrate with the existing evo_handler.php
        // For now, we'll do basic processing
        return content;
    }

    /**
     * Process JavaScript code in .evo files
     */
    processJavaScriptCode(content) {
        // Extract JavaScript code
        const jsMatches = content.match(/<script[^>]*>([\s\S]*?)<\/script>/g);
        
        if (jsMatches) {
            jsMatches.forEach(match => {
                const jsCode = match.replace(/<\/?script[^>]*>/g, '');
                const processed = this.jsHandler.processJavaScript(jsCode, {
                    frameworks: this.frameworks
                });
                
                content = content.replace(match, `<script>${processed.code}</script>`);
            });
        }
        
        return content;
    }

    /**
     * Handle JavaScript file requests
     */
    handleJavaScriptFile(pathname, res) {
        const filePath = path.join(process.cwd(), pathname);
        
        if (!fs.existsSync(filePath)) {
            res.writeHead(404, { 'Content-Type': 'application/javascript' });
            res.end('// File not found');
            return;
        }
        
        const content = fs.readFileSync(filePath, 'utf8');
        res.writeHead(200, { 'Content-Type': 'application/javascript' });
        res.end(content);
    }

    /**
     * Handle CSS file requests
     */
    handleCssFile(pathname, res) {
        const filePath = path.join(process.cwd(), pathname);
        
        if (!fs.existsSync(filePath)) {
            res.writeHead(404, { 'Content-Type': 'text/css' });
            res.end('/* File not found */');
            return;
        }
        
        const content = fs.readFileSync(filePath, 'utf8');
        res.writeHead(200, { 'Content-Type': 'text/css' });
        res.end(content);
    }

    /**
     * Handle API requests
     */
    handleApiRequest(pathname, req, res) {
        // Handle EVO bridge API requests
        if (pathname === '/api/evo-bridge') {
            let body = '';
            req.on('data', chunk => {
                body += chunk.toString();
            });
            
            req.on('end', () => {
                try {
                    const data = JSON.parse(body);
                    const response = this.handleEvoBridgeRequest(data);
                    
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify(response));
                } catch (error) {
                    res.writeHead(400, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'Invalid JSON' }));
                }
            });
        } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'API endpoint not found' }));
        }
    }

    /**
     * Handle EVO bridge requests
     */
    handleEvoBridgeRequest(data) {
        // This would integrate with the existing evo-bridge.php
        return {
            success: true,
            message: 'EVO bridge request processed',
            data: data
        };
    }

    /**
     * Serve static files
     */
    serveStaticFile(pathname, res) {
        const filePath = path.join(process.cwd(), pathname);
        
        if (!fs.existsSync(filePath)) {
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end('<h1>404 - File not found</h1>');
            return;
        }
        
        const content = fs.readFileSync(filePath);
        const ext = path.extname(filePath);
        
        let contentType = 'text/plain';
        switch (ext) {
            case '.html':
                contentType = 'text/html';
                break;
            case '.css':
                contentType = 'text/css';
                break;
            case '.js':
                contentType = 'application/javascript';
                break;
            case '.json':
                contentType = 'application/json';
                break;
            case '.png':
                contentType = 'image/png';
                break;
            case '.jpg':
            case '.jpeg':
                contentType = 'image/jpeg';
                break;
        }
        
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(content);
    }

    /**
     * Setup file watching for hot reload
     */
    setupFileWatching() {
        console.log('👀 Setting up file watching...');
        
        // Watch .evo files
        const evoWatcher = chokidar.watch('**/*.evo', {
            ignored: /node_modules/,
            persistent: true
        });
        
        evoWatcher.on('change', (filePath) => {
            console.log(`🔄 .evo file changed: ${filePath}`);
            this.reloadFile(filePath);
        });
        
        // Watch JavaScript files
        const jsWatcher = chokidar.watch('**/*.js', {
            ignored: /node_modules/,
            persistent: true
        });
        
        jsWatcher.on('change', (filePath) => {
            console.log(`🔄 JavaScript file changed: ${filePath}`);
            this.reloadFile(filePath);
        });
        
        this.watchers.push(evoWatcher, jsWatcher);
    }

    /**
     * Reload file when changed
     */
    reloadFile(filePath) {
        // Send reload signal to connected clients
        console.log(`🔄 Reloading: ${filePath}`);
        // This would implement WebSocket or Server-Sent Events for hot reload
    }

    /**
     * Stop the development server
     */
    stop() {
        console.log('🛑 Stopping EVO Development Server...');
        
        this.watchers.forEach(watcher => {
            watcher.close();
        });
        
        this.isRunning = false;
        console.log('✅ EVO Development Server stopped');
    }
}

// CLI interface
if (require.main === module) {
    const args = process.argv.slice(2);
    const options = {};
    
    // Parse command line arguments
    for (let i = 0; i < args.length; i++) {
        switch (args[i]) {
            case '--port':
                options.port = parseInt(args[++i]);
                break;
            case '--php-port':
                options.phpPort = parseInt(args[++i]);
                break;
            case '--watch':
                options.watch = true;
                break;
            case '--frameworks':
                options.frameworks = args[++i].split(',');
                break;
        }
    }
    
    const server = new EvoDevServer(options);
    
    // Handle graceful shutdown
    process.on('SIGINT', () => {
        server.stop();
        process.exit(0);
    });
    
    process.on('SIGTERM', () => {
        server.stop();
        process.exit(0);
    });
    
    server.start().catch(console.error);
}

module.exports = EvoDevServer;

