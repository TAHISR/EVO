# 🚀 EVO Programming Language

A complete programming language that creates a seamless bridge between PHP and JavaScript, with full framework support and development environment!

## ✨ What is EVO?

EVO is a programming language that solves the problem of PHP and JavaScript not working well together. With EVO, you can:

- **Write PHP in PHP style** - Natural PHP syntax
- **Write JavaScript in JavaScript style** - Natural JavaScript syntax  
- **Use any JavaScript framework** - React, Vue, Tailwind, Node.js, jQuery, Bootstrap
- **Seamless communication** - No complex AJAX setup needed
- **Development environment** - `npm run dev` support
- **IDE support** - Cursor/VSCode extension for syntax highlighting

## 🎯 Key Features

- ✅ **Seamless PHP-JavaScript Bridge** - No complex AJAX setup needed
- ✅ **Framework Support** - React, Vue, Tailwind, Node.js, jQuery, Bootstrap
- ✅ **Development Server** - `npm run dev` with hot reload
- ✅ **IDE Support** - Cursor/VSCode extension with syntax highlighting
- ✅ **Custom EVO Syntax** - Special commands for enhanced functionality
- ✅ **Auto Data Sharing** - PHP variables automatically available in JavaScript
- ✅ **Function Cross-calling** - Call JavaScript functions from PHP and vice versa
- ✅ **Form Handling** - JavaScript handles UI, PHP processes data
- ✅ **Database Integration** - PHP handles databases, JavaScript handles display

## 📁 Files Included

### Core System
- `evo_handler.php` - EVO language processor with PHP-JavaScript bridge
- `evo-bridge.php` - Bridge handler for JavaScript to PHP communication
- `evo-js-handler.js` - JavaScript code handler with framework support
- `evo-dev-server.js` - Development server with hot reload
- `.htaccess` - Apache configuration for .evo files

### Examples
- `example.evo` - Basic example .evo file with PHP only
- `mixed_example.evo` - Advanced example with PHP and JavaScript integration
- `evo_language_demo.evo` - EVO programming language syntax demo
- `php_js_bridge_demo.evo` - Complete PHP-JavaScript bridge demonstration
- `framework-example.evo` - Framework support demonstration

### Development Environment
- `package.json` - npm package configuration
- `evo-language-extension/` - Cursor/VSCode extension for .evo files
- `.vscode/extensions.json` - Recommended extensions

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```

### 3. Alternative: PHP Server
```bash
npm run php
```

### 4. Run Both (Recommended)
```bash
npm run serve
```

## 🎮 Development Commands

```bash
# Start development server with hot reload
npm run dev

# Build for production
npm run build

# Start PHP server
npm run php

# Run JavaScript handler
npm run js

# Run both PHP and JavaScript
npm run serve

# Install framework dependencies
npm run install-deps

# Clean build files
npm run clean

# Lint code
npm run lint

# Format code
npm run format
```

## 🎯 Framework Support

### React
```html
<evo:react UserCard(props) {
    return (
        <div className="user-card">
            <h3>{props.name}</h3>
            <p>{props.email}</p>
        </div>
    );
}>
```

### Vue
```html
<evo:vue ProductCard {
    template: '<div class="product-card"><h3>{{ product.name }}</h3></div>',
    data() {
        return {
            product: { name: 'Laptop', price: 999 }
        };
    }
}>
```

### Tailwind CSS
```html
<evo:tailwind "bg-blue-500 text-white p-4 rounded-lg">
<evo:tailwind "hover:bg-blue-600 transition-colors">
```

### Node.js
```html
<evo:node fs>
<evo:node path>
<evo:node http>
```

### jQuery
```html
<evo:jquery "#myButton">
<evo:jquery ".myClass">
```

### Bootstrap
```html
<evo:bootstrap "btn btn-primary">
<evo:bootstrap "container">
<evo:bootstrap "card">
```

## 🔧 EVO Syntax

### Variables
```html
<evo:var name = "John Doe";>
<evo:var age = 25;>
<evo:var isActive = true;>
```

### Functions
```html
<evo:func greet(name) {
    return "Hello " + name;
}>
```

### Classes
```html
<evo:class User {
    public $name;
    public $email;
}>
```

### Output
```html
<evo:out "Hello World";>
<evo:out $name;>
```

### Data Sharing
```html
<evo:share userData;>  <!-- Share PHP variable with JavaScript -->
<evo:auto config;>     <!-- Auto-bridge PHP variable to JavaScript -->
```

### JavaScript Functions
```html
<evo:jsfunc displayUser() {
    const user = EvoBridge.getPhpData("userData");
    document.getElementById("output").innerHTML = user.name;
}>
```

### PHP Functions
```html
<evo:phpfunc processData($data) {
    return array_sum($data["numbers"]);
}>
```

## 🌉 PHP-JavaScript Bridge

### PHP to JavaScript
```html
<?php
$userData = ['name' => 'John', 'email' => 'john@example.com'];
?>
<script>
// PHP data automatically available in JavaScript
const user = EvoBridge.getPhpData("userData");
console.log(user.name); // "John"
</script>
```

### JavaScript to PHP
```html
<script>
function sendToPhp() {
    const data = {action: "calculate", numbers: [1, 2, 3, 4, 5]};
    EvoBridge.sendToPhp("processData", data);
}
</script>
```

## 🎨 IDE Support

### Cursor/VSCode Extension
1. Install the EVO Language Support extension
2. Open any `.evo` file
3. Get syntax highlighting, snippets, and IntelliSense

### Features
- ✅ Syntax highlighting for EVO, PHP, and JavaScript
- ✅ Code snippets for EVO syntax
- ✅ IntelliSense for EVO functions
- ✅ Error detection and linting
- ✅ Auto-completion for frameworks

## 🔧 Configuration

### package.json
```json
{
  "name": "evo-project",
  "scripts": {
    "dev": "evo-dev-server --watch",
    "build": "evo-build --production",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "evo-bridge": "^1.0.0",
    "evo-js-handler": "^1.0.0"
  }
}
```

### Framework Dependencies
```json
{
  "dependencies": {
    "react": "^18.2.0",
    "vue": "^3.2.0",
    "tailwindcss": "^3.2.0",
    "jquery": "^3.6.0",
    "bootstrap": "^5.2.0"
  }
}
```

## 🚀 Examples

### Basic .evo File
```html
<!DOCTYPE html>
<html>
<head>
    <title>EVO Demo</title>
</head>
<body>
    <h1>EVO Programming Language</h1>
    
    <?php
    $message = "Hello from EVO!";
    $timestamp = date('Y-m-d H:i:s');
    ?>
    
    <p><?php echo $message; ?></p>
    <p>Generated at: <?php echo $timestamp; ?></p>
    
    <button onclick="showAlert()">Click Me!</button>
    
    <script>
        function showAlert() {
            alert('EVO is working!');
        }
    </script>
</body>
</html>
```

### Advanced .evo File with Frameworks
```html
<!DOCTYPE html>
<html>
<head>
    <title>EVO Framework Demo</title>
</head>
<body>
    <h1>EVO Framework Support</h1>
    
    <!-- PHP handles data -->
    <?php
    $products = [
        ['name' => 'Laptop', 'price' => 999],
        ['name' => 'Mouse', 'price' => 29],
        ['name' => 'Keyboard', 'price' => 79]
    ];
    ?>
    
    <!-- Share with JavaScript -->
    <script>EvoBridge.sendToJs({"products": <?php echo json_encode($products); ?>});</script>
    
    <!-- React component -->
    <evo:react ProductCard(props) {
        return (
            <div className="product-card">
                <h3>{props.name}</h3>
                <p>${props.price}</p>
            </div>
        );
    }>
    
    <!-- JavaScript handles UI -->
    <script>
        function renderProducts() {
            const products = EvoBridge.getPhpData("products");
            // Render with React, Vue, or any framework
            products.forEach(product => {
                console.log(`${product.name}: $${product.price}`);
            });
        }
    </script>
</body>
</html>
```

## 🛡️ Security Features

- Direct access to `evo_handler.php` is blocked
- File existence validation
- Extension validation
- Error handling with proper HTTP status codes
- Secure communication between PHP and JavaScript

## 🔧 Troubleshooting

### .evo files not working?
1. Check if `mod_rewrite` is enabled on your Apache server
2. Verify `.htaccess` files are allowed
3. Check file permissions (755 for directories, 644 for files)

### Getting 404 errors?
1. Make sure all files are in the correct directory
2. Check that the .evo file exists
3. Verify the file has the correct `.evo` extension

### Getting 500 errors?
1. Check Apache error logs
2. Verify PHP syntax in your .evo files
3. Make sure `evo_handler.php` has proper permissions

### Framework not working?
1. Install framework dependencies: `npm install`
2. Check if framework is properly imported
3. Verify EVO syntax for the framework

## 📚 Documentation

- [EVO Language Reference](docs/language-reference.md)
- [Framework Integration Guide](docs/framework-integration.md)
- [Development Environment Setup](docs/development-setup.md)
- [API Reference](docs/api-reference.md)

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📄 License

This project is open source and available under the MIT License.

## 🆘 Support

For issues or questions:
1. Check the troubleshooting section
2. Create an issue in the project repository
3. Join our community Discord server

---

**EVO Programming Language** - Where PHP and JavaScript work together seamlessly! 🚀